'use strict';

/**
 * Test setup and mocks
 */

// Mock private key for testing
global.MOCK_PRIVATE_KEY = `-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA0Z91qQKWY1+0yCu7x/bHZPsR+Y8lN2sPwNH9X6kKJ8l6YVn
TEST_PRIVATE_KEY_FOR_TESTING_PURPOSES_ONLY
-----END RSA PRIVATE KEY-----`;

// Mock configuration
global.MOCK_CONFIG = {
  environment: 'sandbox',
  sid: '000000000000010',
  clientNumber: '61938166610',
  privateKey: global.MOCK_PRIVATE_KEY,
  currency: 'EUR',
  keyIndex: 1,
  successUrl: 'http://localhost:3000/success',
  cancelUrl: 'http://localhost:3000/cancel',
  notifyUrl: 'http://localhost:3000/notify',
  lang: 'EN',
  version: '1.4'
};

// Mock cart items
global.MOCK_CART = [
  { name: 'Product 1', price: 50, quantity: 1 },
  { name: 'Product 2', price: 30, quantity: 2 }
];

// Mock customer
global.MOCK_CUSTOMER = {
  email: 'test@example.com',
  firstNames: 'John',
  familyName: 'Doe',
  phone: '+1234567890'
};

// Clear config cache before each test
beforeEach(() => {
  const { clearCache } = require('../config');
  clearCache();
});

